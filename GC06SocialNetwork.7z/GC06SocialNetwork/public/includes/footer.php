<footer class="footer">
  <div class="left-side col-xs-2">
  </div>
  <div class="middle col-sm-6">
    <p>© 2017 - All Rights Reserved</p>
  </div>
  <div class="right-side col-sm-4">
    <p id="footer_names">Created by </p>
  </div>
</footer>
