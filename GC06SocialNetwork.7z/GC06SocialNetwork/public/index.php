<?php include("../server/db_connection.php");

//Using 'phpdotenv' (see here - https://github.com/vlucas/phpdotenv) to manage environment variables.
//The primary 'username_path' variable should be set in '.env' in the root directory & in 3 additional places (see README.md).

require_once  __DIR__ . '../../vendor/autoload.php';

$dotenv = new Dotenv\Dotenv(__DIR__, '../.env');
$dotenv->load();
$username_path = getEnv('username_path');
$dotenv->required('username_path')->notEmpty();

?>

<!DOCTYPE html>
<html lang="en">
<head>

  <?php include("includes/header.php"); ?>

</head>
<body>

  <?php include("includes/navbar.php"); ?>

  <ui-view></ui-view>

  <?php include("includes/footer.php"); ?>

</body>
</html>
