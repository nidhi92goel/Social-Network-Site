
<?php

//1. ------> Local database connection:
$servername='localhost:3306';
$username='root';
$password='';
$database='SocialNetwork';
$conn=New mysqli($servername,$username,$password,$database);


//2. -------> Deployed Azure database connection:
// $servername='eu-cdbr-azure-west-a.cloudapp.net';
// $username='b34de2714f5016';
// $password='f34b83c5';
// $database='gc02ixn_db';
// $conn=New mysqli($servername,$username,$password,$database);


/* __________________________________
|                                    |
|  Error handling / Troubleshooting: |
|____________________________________| */

// echo @mysqli_ping($conn) ? 'true' : 'false';

if(mysqli_connect_errno()) {
  die("Database connection failed: " .
      mysqli_connect_error() .
      " (" . mysqli_connect_errno() . ")"
  );
} else {
  //echo "Connected";
}

?>
