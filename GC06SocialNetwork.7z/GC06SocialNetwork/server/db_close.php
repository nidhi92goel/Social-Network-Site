<?php
//Closing the database connection.
mysqli_close($connection);
?>
